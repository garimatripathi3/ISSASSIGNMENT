#! /bin/bash
#part a
 awk NF < quotes.txt 
 #part b
 sort -u quotes.txt > quotes2.txt
