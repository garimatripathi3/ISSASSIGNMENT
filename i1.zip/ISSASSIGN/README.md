 ## PROJECT NAME 
  ISS  ASSIGNMENT 1
  Garima Tripathi 
   Roll no :- 2021101123

  ## PROJECT DESCRIPTION 
  Consisting of five questions 
  Question 1, 3 ,5 are having subparts .
  3, 5 question subparts are done in diffrent file.
  ### QUESTION 1 
   * * * '''
  ## PART 1(a)
  > Shell script is written for removing empty lines.
  > Have used awk command to remove empty lines from quotes.txt and output have been redirected to new file quotes1.txt.
  > Shell script is written for removing duplicates.
  > Have used sort  command to sort lines from  quotes.txt and -u to remove duplicates, and  output have been redirected to new file quotes2.txt.
  * * *  '''
  ## QUESTION 2 ##
  > Shell script is written to rephrase each line of quotes.txt and redirect output to speech.txt
  > Have used awk command along with print in which field value is written which are to be interchange.
  > Have used awk -F which sets the field seperator.

  ## QUESTION 3
  > Have read file as input variable r.
   ## PART 3(a) ##
  >  Shell script is written for getting size of input file in bytes.
  > Have used wc -c  command to get the size of given  file in bytes, as wc along with c flag return size of file in bytes  and input to wc command  is given with the help of variable r, in which file data have been read.
  > Output of wc command is read in variable p
  > Have printed "Size of  given file is $p  bytes "
  ## PART 3(b) ##
  > Shell script is written for counting total no of lines in file.
  > Have used wc -l command to count total no of lines in file , as wc along with l flag return  total no of lines in input file, input to wc command  is given with the help of variable r, in which file data have been read.
  > Output of wc command is read in variable p
  > Have printed "Total number of lines in given file is $p +1 "
  ## PART 3(c) ##
  >Shell script is written for counting total no of words in file.
  >Have used wc -w command to count total no of words in file , as wc along with w flag return  total no of words in input file, input to wc command  is given with the help of variable r, in which file data have been read.
   Output of wc command is read in variable p
  > Have printed "Total numner of words in  given file is $p +1 "
  ## PART 3(d) ##
 >  Shell script is written for counting  words in each line and printing " Line No : Count of Words"
  > Have printed output with help of awk command as " Line no : total  no of words in line " , with the help of NF and NR ,NR for line , NF for  total no of words in that particular line , have read file with the help of variable r.
  ## PART 3(e)
  > Shell script is written for printing word and how many times they repeated.
  > With the help of sed command put each words on new line, and redirected its output to file.txt
  > With awk NF command removed empty line.
  > Have counted frequency of words in file with grep -c , here c flag helps in counting and have stored value in count variable.
  > If count variable is greater than 1 then have printed word frequency in file2.txt , have removed duplicate lines from file with the help of sort -u command and have again redirected it to file3.txt and have printed content inside it.

* * * '''
## QUESTION 4 ##
* * * '''
> Shell script is written for sorting array only using array and conditional statement 
> Have used simple sort program using two for nested loop and have read input in array with the help of read -a command , have run first for loop from 0 to size of array -2 ,size of array is value of  {arr[@]} , and second loop is run from value of first for loop variable + 1 to size of array -1.
> Have printed whole array again with the help of echo ${arr[*]}, after coming out of  both nested for loop .
* * * '''

## QUESTION 5 ##
* * * '''
## Part a
> Shell script have been written to print reverse of string taken as input.
> Have read the string provided from user and by using command ${#string} size of string is calculated and with the help of for loop starting from last index to zero index , string[index] value have been printed.

## Part b
> Shell script have been written to replace letters in the reverse output with subsequent letter.
> Have read the string provided from user in string variable.
> With the help of for loop have traversed the whole strig.
 > Have read output of echo  "${string:$i:1}" | tr -d "\n" | od -An -t uC) command in r variable to get ascii value of i index of string and have incremented it and again converted it to char value and printed it.

  ## Part c
> Shell script have been written to print reverse of string taken as input.
> Have read the string provided from user and by using command ${#string} size of string is calculated and with the help of for loop starting from (size of string )/2 -1   to zero index , string[index] value have been printed.
> After that with the help of for loop starting from (size of string )/2   to (size of string ) -1  , string[index] value have been printed.
* * * '''
* * * COMMAND TO RUN
## 1a
chmod +x 1.sh
./1a.sh
## 1b
chmod +x 1.sh
./1b.sh
## 2
chmod +x 2.sh
./2.sh
## 3a
chmod +x 3a.sh
./3a.sh
After that provide file name
## 3b
chmod +x 3b.sh
./3b.sh
After that provide file name
## 3c
chmod +x 3c.sh
./3c.sh
After that provide file name
## 3d
chmod +x 3d.sh
./3d.sh
After that provide file name
## 4 
./4.sh
Provide sample input to be sorted.
## GITHUB REPO ##
https://github.com/garima700/ISSASSIGNMENT.git







