#! /bin/bash
read -a arr
for ((i = 0; i<${#arr[@]}-1; i++))
do  
    for((j = i+1; j<${#arr[@]}; j++))
    do
   
        if [ ${arr[i]} -gt ${arr[j]} ]
        then
            t=${arr[j]}
            arr[j]=${arr[i]}  
            arr[i]=$t
        fi
    done
done
echo ${arr[*]}