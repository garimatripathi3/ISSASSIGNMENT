
#!/ bin / bash
read string
for (( i=${#string}-1; i>=0; i-- )) do
  echo -n "${string:$i:1}"
done
#part b
printf "\n"
for (( i=${#string}-1; i>=0; i-- )) 
do
  read r < <(echo  "${string:$i:1}" | tr -d "\n" | od -An -t uC)
  if [[ $r -eq 90 ]]
  then
  r=65
  elif [[ $r -eq 122 ]]
  then 
  r=97
  else
let "r=r+1"
fi
set $(printf %x $r)
printf "\x$1"
done
printf "\n"
#part c
read s
for (( i=((${#s}))/2-1; i>=0; i-- )) do
  echo -n "${s:$i:1}"
done
for (( i=((${#s}))/2; i<${#s}; i++ )) do
  echo -n "${s:$i:1}"
done



