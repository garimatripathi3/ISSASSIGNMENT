#! /bin/bash
read r 
#part a
 read p < <(wc -c < $r) 
 echo Size of given  file is $p bytes.
 #part b
 read p < <(wc -l < $r)
 echo Total number of lines in given file is $p + 1.
 #part c
 read p < <(wc -w < $r) 
 echo Total number of words in given file is $p
 #part d
awk '$0=" Line no "NR" : Count of words :  "NF'  $r
#part e
sed -i "s/ /\n/g" ./$r 
awk NF <  $r > file.txt
while read line
do
     count="$(grep -c $line file.txt)"
     if [[ $count > 1 ]]
     then
     echo $line : $count > file2.txt
      fi
done < ./file.txt
sort -u  file2.txt > file3.txt
cat file3.txt
